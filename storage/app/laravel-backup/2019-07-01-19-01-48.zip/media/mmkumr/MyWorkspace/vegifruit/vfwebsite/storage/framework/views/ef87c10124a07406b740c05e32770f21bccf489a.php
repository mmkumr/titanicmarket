<?php $__env->startSection('title', 'shop'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container" style = 'padding-top: 150px;padding-bottom: 30px;'>
                <?php if(session()->has('success_message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success_message')); ?>

                </div>
                <?php endif; ?>

                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

        <div class="row">
			<div class="col-xl-3 col-lg-4 col-md-5">
				<div class="sidebar-categories">
					<div class="head">Browse Categories</div>
					<ul class="main-categories">
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="main-nav-list child"><a href="<?php echo e(route('shop.index', ['category' => $category->slug])); ?>"><?php echo e($category->name); ?><span class="number">(<?php echo e($productcount($category->id)); ?>)</span></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			</div>
			<div class="col-xl-9 col-lg-8 col-md-7">
				<!-- Start Filter Bar -->
				<div class="filter-bar d-flex flex-wrap align-items-center ">
					<div class="sorting">
                        <select onchange="if(this.value == 1){
                                                                window.location.href = '<?php echo e(route('shop.index', ['category'=> request()->category, 'sort' => 'low_high'])); ?>'
                                                             }
                                          else {
                                                    window.location.href = '<?php echo e(route('shop.index', ['category'=> request()->category, 'sort' => 'high_low'])); ?>'
                                                }">
							<option value="1">Price: Low to High</option>
							<option value="2">Price: Higt to Low</option>
						</select>
					</div>
				</div>
				<!-- End Filter Bar -->
                <!-- Start Best Seller -->
				<section class="lattest-product-area pb-40 category-list">
                    <div class="row">
                    <?php ($i = 0); ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<!-- single product -->
						<div class="col-lg-4 col-md-6">
							<div class="single-product">
								<a href="<?php echo e(route('shop.show', $product->slug)); ?>"><img class="img-fluid" src="<?php echo e(productImage($product->image)); ?>" alt=""></a>
								<div class="product-details">
									<a href="<?php echo e(route('shop.show', $product->slug)); ?>"><h6><?php echo e($product->name); ?></h6></a>
									<div class="price">
										<h6><?php echo e($product->presentPrice()); ?></h6>
										<h6 class="l-through">$150.00</h6>
                                    </div>
                                    <form action="<?php echo e(route('cart.store', $product)); ?>" method="POST" class = "link-form-bag">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
									<div class="prd-bottom">
										<a href="javascript:document.getElementsByClassName('link-form-bag')[<?php echo e($i); ?>].submit()"  class="social-info">
											<span class="ti-bag"></span>
											<p class="hover-text">add to bag</p>
										</a>
										<a href="<?php echo e(route('shop.show', $product->slug)); ?>" class="social-info">
											<span class="lnr lnr-move"></span>
											<p class="hover-text">view more</p>
										</a>
									</div>
								</div>
							</div>
                        </div>
                        <?php ($i = $i + 1); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
				</section>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/mmkumr/MyWorkspace/vegifruit/vfwebsite/resources/views/category.blade.php ENDPATH**/ ?>