<!--
		CSS
		============================================= -->
	<link rel="stylesheet" href="<?php echo e(asset('css/linearicons.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/themify-icons.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/nice-select.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/nouislider.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/ion.rangeSlider.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/ion.rangeSlider.skinFlat.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">    
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>"> 
    <link rel="stylesheet" href="<?php echo e(asset('css/algolia.css')); ?>">

<?php /**PATH /media/mmkumr/MyWorkspace/vegifruit/vfwebsite/resources/views/partials/css.blade.php ENDPATH**/ ?>