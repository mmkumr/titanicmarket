<script src="<?php echo e(asset('js/vendor/jquery-2.2.4.min.js')); ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4"
	 crossorigin="anonymous"></script>
	<script src="<?php echo e(asset('js/vendor/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.ajaxchimp.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.nice-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.sticky.js')); ?>"></script>
	<script src="<?php echo e(asset('js/nouislider.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/countdown.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script> 	
    <script src="https://cdn.jsdelivr.net/algoliasearch/3/algoliasearch.min.js"></script>
    <script src="https://cdn.jsdelivr.net/autocomplete.js/0/autocomplete.min.js"></script>
    <script src="<?php echo e(asset('js/algolia.js')); ?>"></script>
    <script src="<?php echo e(asset('js/algolia.js')); ?>"></script>
<!--gmaps Js-->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAF3OlFHBtuyIec5x2Nc2RQlCO52nN5xcU"></script>
	<script src="<?php echo e(asset('js/gmaps.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
<?php /**PATH /media/mmkumr/MyWorkspace/vegifruit/vfwebsite/resources/views/partials/js.blade.php ENDPATH**/ ?>