<?php echo e($slot); ?>

<?php /**PATH /media/mmkumr/MyWorkspace/vegifruit/vfwebsite/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>