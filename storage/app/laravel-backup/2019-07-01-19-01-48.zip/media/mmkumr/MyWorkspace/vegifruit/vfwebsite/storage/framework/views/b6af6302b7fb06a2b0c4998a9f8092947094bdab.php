<?php $__env->startSection('title', 'cart'); ?>
    <!--================Cart Area =================-->
    <section class="cart_area">
        <div class="container">
            <div class="cart_inner">
                <?php if(session()->has('success_message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success_message')); ?>

                </div>
                <?php endif; ?>

                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <div class="table-responsive">
                <?php if(Cart::count() > 0): ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Product</th>
                                <th scope="col">Price</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Total</th>
                                <th scope="col">Buttons</th>

                            </tr>
                        </thead>
                        <tbody>
                        <?php ($t = 0); ?> 
                        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="media">
                                        <div class="d-flex">
                                            <a href="<?php echo e(route('shop.show', $item->model->slug)); ?>">
                                                <img src="<?php echo e(productImage($item->model->image)); ?>" alt="item">
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <a href="<?php echo e(route('shop.show', $item->model->slug)); ?>">
                                                <h3><?php echo e($item->model->name); ?></h3><br>
                                            </a>
                                            <p><?php echo e($item->model->details); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <h5><?php echo e(presentPrice($item->model->price)); ?></h5>
                                </td>
                                <td>
                                    <?php ($tprice = $item->model->price); ?>
                                    <div class="product_count">
                                    <select class="quantity" data-id="<?php echo e($item->rowId); ?>" data-productQuantity="<?php echo e($item->model->quantity); ?>" onchange="x = <?php echo e($tprice); ?> * (this.value); document.getElementsByTagName('h4')[<?php echo e($t); ?>].innerHTML = '₹' + x/100;
                                   var sum = 0;
                                   Array.from(document.querySelectorAll('h4')).forEach(function(element) { 
                                   sum += Number(element.innerHTML.slice(1)) 
                                   });
                                   element = document.getElementsByTagName('select')['<?php echo e($t); ?>'];
                                   const id = element.getAttribute('data-id');
                                   const productQuantity = element.getAttribute('data-productQuantity');
                                   axios.patch(`/cart/${id}`, {
                        										quantity: this.value,
                        										productQuantity: productQuantity
                                   });
                                   document.querySelectorAll('p')[<?php echo e(count(Cart::content())); ?>].innerText = '₹' + sum;
                                   document.querySelectorAll('p')[<?php echo e(count(Cart::content())); ?> + 2].innerText = '₹' + (sum - <?php echo e(trim(presentPrice($discount), '₹')); ?>);
                                   sum = 0
                                        ">
                                            <?php for($i = 1; $i < 5 + 1 ; $i++): ?>
                                                <option <?php echo e($item->qty == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                            <?php endfor; ?>

                                        </select>
                                    </div>
                                       <td> 
                                           <h4><?php echo e(presentPrice($tprice * $item->qty)); ?></h4>
                                        </td>
                                    </div>
                                </td>
                                <td>
                                <form action="<?php echo e(route('cart.destroy', $item->rowId)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>


                                    <button type="submit" class="cart-options">Remove</button>
                                </form>

                                <form action="<?php echo e(route('cart.switchToSaveForLater', $item->rowId)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <button type="submit" class="cart-options">Add to wishlist</button>
                                </form>
                                </td>
                            </tr>
                            <?php ($t = $t + 1); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            </tr>
                            <tr class="bottom_button">
                                <td>
                                </td>
                                <td>

                                </td>
                                <td>

                                </td>
                                <td>
                                    <div class="cupon_text d-flex align-items-center" align = right>
                                        <form action="<?php echo e(route('coupon.store')); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="text" name="coupon_code" placeholder="Coupon Code">
                                            <button type="submit" class="primary-btn">Apply</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>

                                </td>
                                <td>

                                </td>
                                <td>
                                    <?php if(session()->has('coupon')): ?>
                                    <h3>Coupon code</h3>
                                        Code (<?php echo e(session()->get('coupon')['name']); ?>)
                                        <form action="<?php echo e(route('coupon.destroy')); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('delete')); ?>

                                            <button type="submit" style="font-size:14px;">Remove</button>
                                        </form>
                                        <?php endif; ?>
                                </td>
                                <td>
                                    <h3>Subtotal</h3>
                                    <p align = 'center'>₹<?php echo e(trim(presentPrice($newTotal), '₹') + trim(presentPrice($discount), '₹')); ?></p>
                                    <p align = 'center'>- <?php echo e(presentPrice($discount)); ?></p>
                                    <h5 align = 'center'>Total</h5>
                                    <p align = 'center'>₹<?php echo e(trim(presentPrice($newTotal), '₹')); ?></p>
                                </td>
                                <td>
                                </td>
                            </tr>
                            <tr class="shipping_area">

                                </td>
                                <td>

                                </td>
                                <tr class="out_button_area">
                                <td>

                                </td>
                                <td>

                                </td>
                                <td>

                                </td>
                                <td>
                                    <div class="checkout_btn_inner d-flex align-items-center">
                                        <a class="gray_btn" href="/">Continue Shopping</a>
                                        <a class="primary-btn" href="<?php echo e(route('checkout.index')); ?>">Proceed to checkout</a>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <h3 align = center>No items in the cart!</h3>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="bottom_button">
                                <tr class="out_button_area">
                                <td>
                                </td>
                                <td>
                                </td>
                                <td>
                                </td>
                                <td>
                                </td>
                                <td>
                                </td>
                                <td>
                                </td>
                                <td>
                                </td>
                                <td>
                                </td>
                                <td>
                                </td>
                                <td>
                                </td>
                                <td>
                                </td>
                                <td>
                                </td>
                                <td>
                                    <div class="checkout_btn_inner d-flex align-items-center">
                                        <a class="gray_btn" href="/">Continue Shopping</a>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <?php endif; ?>
                    <?php if(Cart::instance('saveForLater')->count() > 0): ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Product</th>
                                <th scope="col"></th>
                                <th scope="col"></th>
                                <th scope="col">Price</th>
                                <th scope="col">Buttons</th>

                            </tr>
                        </thead>
                        <tbody>
                        <h2 align = 'center'>Wishlist</h2> 
                        <?php $__currentLoopData = Cart::instance('saveForLater')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="media">
                                        <div class="d-flex">
                                            <a href="<?php echo e(route('shop.show', $item->model->slug)); ?>">
                                                <img src="<?php echo e(productImage($item->model->image)); ?>" alt="item">
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <a href="<?php echo e(route('shop.show', $item->model->slug)); ?>">
                                                <h3><?php echo e($item->model->name); ?></h3><br>
                                            </a>
                                            <p><?php echo e($item->model->details); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                </td>
                                <td>
                                </td>
                                    
                                       <td> 
                                           <h5><?php echo e(presentPrice($item->model->price)); ?></h5>
                                        </td>
                                    </div>
                                </td>
                                <td>
                                <form action="<?php echo e(route('saveForLater.destroy', $item->rowId)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" class="cart-options">Remove</button>
                                </form>
                                <form action="<?php echo e(route('saveForLater.switchToCart', $item->rowId)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <button type="submit" class="cart-options">Move to Cart</button>
                                </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            </tr>
                            <tr class="bottom_button">
                            <tr class="shipping_area">
                                </td>
                                <td>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <!--================End Cart Area =================-->

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/mmkumr/MyWorkspace/vegifruit/vfwebsite/resources/views/cart.blade.php ENDPATH**/ ?>