<p>Name: <?php echo e($name); ?></p>
<p>Subject: <?php echo e($subject); ?></p>
<p>Email: <?php echo e($email); ?></p>
<p>Message: <?php echo e($user_message); ?></p>
<?php /**PATH /media/mmkumr/MyWorkspace/vegifruit/vfwebsite/resources/views/email.blade.php ENDPATH**/ ?>