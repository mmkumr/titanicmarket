<p>Name: {{ $name }}</p>
<p>Subject: {{ $subject }}</p>
<p>Email: {{ $email }}</p>
<p>Message: {{ $user_message }}</p>
