<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>

	<!--================Single Product Area =================-->
	<div class="product_image_area" style = "padding:150px">
		<div class="container">
			<div class="row s_product_inner">
                <div class="col-lg-6">
                <?php if(session()->has('success_message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success_message')); ?>

                    </div>
                <?php endif; ?>

                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                    <div class="s_Product_carousel">
                        <div class="single-prd-item">
                                <img class="img-fluid" src="<?php echo e(productImage($product->image)); ?>" alt="">
                        </div>
                        <?php if($product->images): ?>
                            <?php $__currentLoopData = json_decode($product->images, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-prd-item">
                                <img class="img-fluid" src="<?php echo e(productImage($image)); ?>" alt="">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
					</div>
				</div>
				<div class="col-lg-5 offset-lg-1">
					<div class="s_product_text">
						<h3><?php echo e($product->name); ?></h3>
						<h2><?php echo e($product->presentPrice()); ?></h2>
						<ul class="list">
							<li><span>Category</span> : <?php echo e($categories->where('id', $cid)->first()->name); ?></li>
							<li><span>Availibility</span> : <?php echo $stockLevel; ?></li>
						</ul>
                        <div class="card_area d-flex align-items-center">
                        <?php if($product->quantity > 0): ?>
                        <form action="<?php echo e(route('cart.store', $product)); ?>" method="POST" id = "cart">
                            <?php echo e(csrf_field()); ?>

                        </form>
                            <a class="primary-btn" href="#" onclick="document.getElementById('cart').submit()">Add to Cart</a>
                        <?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--================End Single Product Area =================-->

	<!--================Product Description Area =================-->
	<section class="product_description_area">
		<div class="container">
		    <h1>Description</h1>	
                    <p><?php echo e($product->description); ?></p>
        </div>
	</section>
    <!--================End Product Description Area =================-->
	<!-- Start related-product Area -->
	<section class="related-product-area section_gap_bottom">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-6 text-center">
					<div class="section-title">
						<h1>Deals of the Week</h1>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore
							magna aliqua.</p>
					</div>
				</div>
            </div>
            <h2 align = 'center'>Might Also Like to Purchase.</h2>
			<div class="row" style = "padding-top:20px">
				<div class="col-lg-12">
					<div class="row">
                    <?php $__currentLoopData = $mightAlsoLike; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-4 col-md-4 col-sm-6 mb-20">
							<div class="single-related-product d-flex">
								<a href="<?php echo e(route('shop.show', $product->slug)); ?>"><img src="<?php echo e(productImage($product->image)); ?>" alt=""></a>
								<div class="desc">
									<a href="<?php echo e(route('shop.show', $product->slug)); ?>" class="title"><?php echo e($product->name); ?></a>
									<div class="price">
										<h6><?php echo e($product->presentPrice()); ?></h6>
									</div>
								</div>
							</div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End related-product Area -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/mmkumr/MyWorkspace/vegifruit/vfwebsite/resources/views/product.blade.php ENDPATH**/ ?>