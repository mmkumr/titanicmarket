<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="img/fav.png">
	<!-- Author Meta -->
	<meta name="author" content="CodePixar">
	<!-- Meta Description -->
	<meta name="description" content="">
	<!-- Meta Keyword -->
	<meta name="keywords" content="">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title>Vegifruit| Login page</title>

    <?php echo $__env->make('partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--================Login Box Area =================-->
    

    <section class="login_box_area section_gap">
        <div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="login_box_img">
						<img class="img-fluid" src="img/login.jpg" alt="">
						<div class="hover">
							<h4>New to our website</h4>
                            <a class="primary-btn" href="<?php echo e(route('register')); ?>">Create an Account</a><br>
                            <a class="primary-btn" href="<?php echo e(route('guestCheckout.index')); ?>">Guest Account</a>
						</div>
					</div>
				</div>
                <div class="col-lg-6">
                    
                    <div class="login_form_inner">
                        <?php if(session()->has('success_message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('success_message')); ?>

                            </div>
                            <?php endif; ?> <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <h3>Log in to enter</h3>
                        <form class="row login_form" action="<?php echo e(route('login')); ?>" method="POST" id="contactForm">
                            <?php echo e(csrf_field()); ?>

							<div class="col-md-12 form-group">
								<input type="email" class="form-control" id="name" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Username'"required autofocus>
							</div>
							<div class="col-md-12 form-group">
								<input type="password" class="form-control" id="name" name="password" value="<?php echo e(old('password')); ?>" placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'" required>
							</div>
							<div class="col-md-12 form-group">
								<div class="creat_account">
							    	<label>
                                        <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                    </label>							
                                </div>
							</div>
							<div class="col-md-12 form-group">
								<button type="submit" class="primary-btn">Log In</button>
								<a href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--================End Login Box Area =================-->

    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</body>

</html>
<?php /**PATH /media/mmkumr/MyWorkspace/vegifruit/vfwebsite/resources/views/login.blade.php ENDPATH**/ ?>