<?php $__env->startSection('title', 'Reset Password'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="auth-pages">
        <div class="auth-left">
            <?php if(session()->has('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('status')); ?>

            </div>
            <?php endif; ?> <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <h2>Forgot Password?</h2>
            <div class="spacer"></div>
            <form action="<?php echo e(route('password.email')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required autofocus>
                <div class="login-container">
                    <button type="submit" class="auth-button">Send Password Reset Link</button>
                </div>


            </form>
        </div>
        <div class="auth-right">
            <h2>Forgotten Password Information</h2>
            <div class="spacer"></div>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel dicta obcaecati exercitationem ut atque inventore cum. Magni autem error ut!</p>
            <div class="spacer"></div>
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Vel accusantium quasi necessitatibus rerum fugiat eos, a repudiandae tempore nisi ipsa delectus sunt natus!</p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/mmkumr/MyWorkspace/vegifruit/vfwebsite/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>